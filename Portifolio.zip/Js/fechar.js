let fechar = document.getElementById("btt-ifram");
let pgpoup = document.getElementById("poupUp")
let fecharPacote = document.getElementById("basico")
let fecharPacote2 = document.getElementById("avancado")
let radio = document.getElementById("bt-r")
let radio2 = document.getElementById("bt-r2")


function Fechar() {
    pgpoup.style.display = "none";
    fecharPacote.style.display = "block";
    fecharPacote2.style.display = "block";
    radio.style.display = "block";
    radio2.style.display = "block";
    document.getElementById("nome").setAttribute("required","obrigatorio");
    document.getElementById("email").setAttribute("required", "obrigatorio");
    document.getElementById("telefone").setAttribute("required", "obrigatorio");
    document.getElementById("radio3").removeAttribute("required");
}

function SaibaMais(){
  pgpoup.style.display = "block";
  fecharPacote.style.display = "none";
  fecharPacote2.style.display = "none";
  radio.style.display = "none";
  radio2.style.display = "none";
  document.getElementById("radio").setAttribute("required","obrigatorio");
  document.getElementById("nome").removeAttribute("required");
  document.getElementById("email").removeAttribute("required");
  document.getElementById("telefone").removeAttribute("required");
  document.getElementById("radio3").setAttribute("required", "obrigatorio");
}
