let meuBotao = document.getElementById("botaoVoltar");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.documentElement.scrollTop > 100) {
    meuBotao.style.display = "block";
  } else {
    meuBotao.style.display = "none";
  }
}