function Email(){
  console.log("Clicou")
  window.open('https://wa.me/67984736182?text=Ol%C3%A1,%20me%20chamo%20(Seu%20Nome),%20gostaria%20de%20saber%20mais%20mais%20informa%C3%A7%C3%B5es%20sobre%20os%20sites%20:)');
}